import { NextRequest, NextResponse } from "next/server";
import { createServerSupabase } from "@/lib/supabase/server";

// This route connects to Claude with LIVE database context.
// Every request pulls fresh data from Supabase so the assistant always
// knows the current state of the pipeline.

const BASE_SYSTEM_PROMPT = `You are the AI executive assistant for John Mathewson at Stewardship Asset Group, a commercial real estate brokerage in Northwest Indiana. You have FULL access to the CRE Intelligence Platform database — the data below is LIVE from the system.

Your personality: direct, knowledgeable, proactive. You think like a senior CRE broker's chief of staff. You don't just answer questions — you identify what John should be doing next and suggest actions.

Capabilities you can offer:
- Analyze deals, run comp scenarios, calculate commission projections
- Draft emails, LOIs, follow-up messages
- Identify signals and opportunities in the pipeline
- Surface contacts who need attention
- Generate market insights based on the data

Rules:
- Be concise but thorough
- Always suggest next actions
- Format financial numbers clearly ($1,234,567 format)
- If John asks you to DO something (not just analyze), confirm what you'll do
- The only things you CANNOT do autonomously: wire money or send emails to clients without confirm`;

function formatCurrency(n: number | null | undefined): string {
  if (n == null || isNaN(n)) return "TBD";
  return "$" + n.toLocaleString("en-US", { minimumFractionDigits: 0, maximumFractionDigits: 0 });
}

async function buildLiveContext(): Promise<string> {
  const supabase = createServerSupabase();
  const sections: string[] = [];

  // --- Deals with latest stage ---
  const { data: deals } = await supabase
    .from("deals")
    .select("id, deal_name, deal_type, price, commission_pct, estimated_commission, weighted_commission, probability_pct, expected_close, is_dead, notes, property_id, client_contact_id")
    .order("weighted_commission", { ascending: false });

  const { data: stages } = await supabase
    .from("deal_stages")
    .select("deal_id, stage, entered_at")
    .order("entered_at", { ascending: false });

  // Build a map of deal_id -> latest stage
  const stageMap: Record<string, string> = {};
  if (stages) {
    for (const s of stages) {
      if (!stageMap[s.deal_id]) stageMap[s.deal_id] = s.stage;
    }
  }

  if (deals && deals.length > 0) {
    const active = deals.filter((d) => !d.is_dead);
    const dead = deals.filter((d) => d.is_dead);
    const closed = active.filter((d) => stageMap[d.id] === "Closed");
    const pipeline = active.filter((d) => stageMap[d.id] !== "Closed");

    const pipelineValue = pipeline.reduce((s, d) => s + (d.estimated_commission || 0), 0);
    const weightedValue = pipeline.reduce((s, d) => s + (d.weighted_commission || 0), 0);
    const earnedYTD = closed.reduce((s, d) => s + (d.estimated_commission || 0), 0);

    sections.push(`## Pipeline Summary
- Total deals: ${deals.length} (${pipeline.length} active pipeline, ${closed.length} closed, ${dead.length} dead)
- Pipeline commission: ${formatCurrency(pipelineValue)}
- Weighted pipeline: ${formatCurrency(weightedValue)}
- Earned YTD: ${formatCurrency(earnedYTD)}
- 2026 Goal: $2,000,000`);

    if (pipeline.length > 0) {
      const dealLines = pipeline.map((d, i) => {
        const stage = stageMap[d.id] || "Unknown";
        return `${i + 1}. ${d.deal_name} — ${formatCurrency(d.price)}, ${d.deal_type || "sale"}, ${d.commission_pct || 0}% commission, ${d.probability_pct || 0}% prob (${formatCurrency(d.weighted_commission)} weighted) — ${stage}`;
      });
      sections.push(`## Active Pipeline (by weighted commission)\n${dealLines.join("\n")}`);
    }

    if (closed.length > 0) {
      const closedLines = closed.map(
        (d) => `- ${d.deal_name} — ${formatCurrency(d.estimated_commission)} earned`
      );
      sections.push(`## Closed Deals\n${closedLines.join("\n")}`);
    }
  }

  // --- Properties ---
  const { data: properties } = await supabase
    .from("properties")
    .select("id, name, address, city, state, asset_type, status, asking_price, lease_rate, sqft, your_role")
    .order("asking_price", { ascending: false });

  if (properties && properties.length > 0) {
    const propLines = properties.map(
      (p) => `- ${p.name || p.address}: ${p.asset_type || "Unknown"}, ${p.status || "Active"}, ${formatCurrency(p.asking_price)}, ${p.sqft ? p.sqft.toLocaleString() + " SF" : "SF TBD"}, ${p.city || ""} ${p.state || ""}${p.your_role ? " (" + p.your_role + ")" : ""}`
    );
    sections.push(`## Properties (${properties.length} total)\n${propLines.join("\n")}`);
  }

  // --- Contacts ---
  const { data: contacts } = await supabase
    .from("contacts")
    .select("id, full_name, contact_type, warmth, email, phone, city, state, last_contacted_at, company_id")
    .order("full_name");

  if (contacts && contacts.length > 0) {
    const hot = contacts.filter((c) => c.warmth === "hot");
    const warm = contacts.filter((c) => c.warmth === "warm");
    const cold = contacts.filter((c) => c.warmth === "cold" || !c.warmth);

    // Find contacts not reached in 30+ days
    const now = new Date();
    const stale = contacts.filter((c) => {
      if (!c.last_contacted_at) return true;
      const diff = now.getTime() - new Date(c.last_contacted_at).getTime();
      return diff > 30 * 24 * 60 * 60 * 1000;
    });

    sections.push(`## Contacts (${contacts.length} total)
- Hot: ${hot.length}, Warm: ${warm.length}, Cold/Unset: ${cold.length}
- Stale (30+ days no contact): ${stale.length}

Key contacts:\n${contacts.slice(0, 20).map((c) => `- ${c.full_name} (${c.contact_type || "unknown"}, ${c.warmth || "unset"})${c.city ? " — " + c.city + ", " + (c.state || "") : ""}`).join("\n")}`);
  }

  // --- Companies ---
  const { data: companies } = await supabase
    .from("companies")
    .select("id, name, company_type")
    .order("name");

  if (companies && companies.length > 0) {
    sections.push(`## Companies (${companies.length})\n${companies.map((c) => `- ${c.name} (${c.company_type || "unknown"})`).join("\n")}`);
  }

  return sections.join("\n\n");
}

export async function POST(req: NextRequest) {
  try {
    const { message } = await req.json();

    if (!message?.trim()) {
      return NextResponse.json({ error: "No message provided" }, { status: 400 });
    }

    const apiKey = process.env.ANTHROPIC_API_KEY;

    if (!apiKey || apiKey === "YOUR_ANTHROPIC_API_KEY_HERE") {
      return NextResponse.json({
        response: "API key not configured. Please set ANTHROPIC_API_KEY in your environment.",
        actions: ["Show details"],
      });
    }

    // Pull live data from Supabase
    const liveContext = await buildLiveContext();

    const systemPrompt = `${BASE_SYSTEM_PROMPT}

--- LIVE DATABASE SNAPSHOT (as of ${new Date().toLocaleString("en-US", { timeZone: "America/Chicago" })}) ---

${liveContext}

--- END DATABASE SNAPSHOT ---

Use this data to answer John's questions accurately. Reference specific deal names, contact names, and numbers from the live data above.`;

    // Call Claude
    const response = await fetch("https://api.anthropic.com/v1/messages", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "x-api-key": apiKey,
        "anthropic-version": "2023-06-01",
      },
      body: JSON.stringify({
        model: "claude-sonnet-4-20250514",
        max_tokens: 1500,
        system: systemPrompt,
        messages: [{ role: "user", content: message }],
      }),
    });

    const data = await response.json();

    if (!response.ok) {
      return NextResponse.json(
        { error: data.error?.message || "API error" },
        { status: response.status }
      );
    }

    const text =
      data.content?.[0]?.type === "text" ? data.content[0].text : "No response.";

    const actions = extractActions(text);

    return NextResponse.json({ response: text, actions });
  } catch (error) {
    console.error("Assistant error:", error);
    return NextResponse.json(
      { error: "Failed to process request" },
      { status: 500 }
    );
  }
}

function extractActions(text: string): string[] {
  const actions: string[] = [];
  if (/email|draft|send|outreach/i.test(text)) actions.push("Draft emails");
  if (/schedul|task|follow.?up|remind/i.test(text)) actions.push("Schedule tasks");
  if (/tour|show|view|detail|look/i.test(text)) actions.push("Show details");
  if (/report|analy|comp/i.test(text)) actions.push("Generate report");
  if (/call|phone|contact/i.test(text)) actions.push("Log activity");
  if (actions.length === 0) actions.push("Show details");
  return actions.slice(0, 3);
}
