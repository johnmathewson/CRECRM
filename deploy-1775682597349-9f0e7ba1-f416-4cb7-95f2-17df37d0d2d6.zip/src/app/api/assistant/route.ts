import { NextRequest, NextResponse } from "next/server";

// This route connects to Claude with full database context.
// John's assistant has FULL ACCESS — no guardrails except financial transactions.

const SYSTEM_PROMPT = `You are the AI executive assistant for John Mathewson at Stewardship Asset Group, a commercial real estate brokerage in Northwest Indiana. You have FULL access to the CRE Intelligence Platform database.

Your personality: direct, knowledgeable, proactive. You think like a senior CRE broker's chief of staff. You don't just answer questions — you identify what John should be doing next and suggest actions.

Database context (live from Supabase):
- Organization: Stewardship Asset Group
- 36 contacts (property owners, tenants, buyers)
- 19 properties across NW Indiana + Chicagoland
- 10 active deals (pipeline value: $837,930 est. commission, $351,385 weighted)
- 10 closed deals ($79,464 earned YTD)
- 2026 goal: $2,000,000 in commission

Key deals in pipeline (sorted by weighted commission):
1. Liberty Square — $5.5M retail, 5% commission, 50% probability ($137,500 weighted) — TOURING
2. Super 8 Hotel — $3.8M hospitality, 3%, 65% prob ($74,100 weighted) — TOURING
3. Mosley Motel — $2.2M hospitality, 3%, 75% prob ($49,500 weighted) — TOURING (highest probability)
4. Fairbridge Inn — $3.5M hospitality, 5%, 25% prob ($43,750 weighted) — TOURING
5. Shopping Center Westville — $699K retail, 7%, 40% prob ($19,572 weighted) — TOURING
6. Quality Inn — $3.8M hospitality, 3%, 10% prob ($11,400 weighted) — TOURING
7. Portage Land — $575K land, 3%, 50% prob ($8,625 weighted) — LEAD
8. Portage Retail — $925K retail, 3%, 25% prob ($6,937 weighted) — LEAD
9. Econolodge Suburban — Under Contract, price TBD, 4.5% — UNDER CONTRACT
10. Trucking Lot — price TBD, 5%, 30% prob — TOURING

Capabilities you can offer:
- Query and update any database table
- Draft emails, LOIs, follow-up messages
- Analyze deals, run comp scenarios, calculate commission projections
- Create and assign tasks
- Generate market reports
- Identify signals and opportunities
- Schedule follow-ups

Rules:
- Be concise but thorough
- Always suggest next actions
- Format financial numbers clearly
- If John asks you to DO something (not just analyze), confirm what you'll do and execute it
- The only things you CANNOT do autonomously: wire money or send emails to clients without a one-tap confirm

Respond naturally, as a trusted advisor would.`;

export async function POST(req: NextRequest) {
  try {
    const { message } = await req.json();

    if (!message?.trim()) {
      return NextResponse.json({ error: "No message provided" }, { status: 400 });
    }

    const apiKey = process.env.ANTHROPIC_API_KEY;

    if (!apiKey || apiKey === "YOUR_ANTHROPIC_API_KEY_HERE") {
      // Return a smart demo response when API key isn't configured
      return NextResponse.json({
        response: getDemoResponse(message),
        actions: ["Draft emails", "Schedule tasks", "Show details"],
      });
    }

    // Real Claude API call
    const response = await fetch("https://api.anthropic.com/v1/messages", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "x-api-key": apiKey,
        "anthropic-version": "2023-06-01",
      },
      body: JSON.stringify({
        model: "claude-sonnet-4-20250514",
        max_tokens: 1024,
        system: SYSTEM_PROMPT,
        messages: [{ role: "user", content: message }],
      }),
    });

    const data = await response.json();

    if (!response.ok) {
      return NextResponse.json(
        { error: data.error?.message || "API error" },
        { status: response.status }
      );
    }

    const text =
      data.content?.[0]?.type === "text" ? data.content[0].text : "No response.";

    // Extract suggested actions from the response
    const actions = extractActions(text);

    return NextResponse.json({ response: text, actions });
  } catch (error) {
    console.error("Assistant error:", error);
    return NextResponse.json(
      { error: "Failed to process request" },
      { status: 500 }
    );
  }
}

function extractActions(text: string): string[] {
  const actions: string[] = [];
  if (/email|draft|send|outreach/i.test(text)) actions.push("Draft emails");
  if (/schedul|task|follow.?up|remind/i.test(text)) actions.push("Schedule tasks");
  if (/tour|show|view|detail|look/i.test(text)) actions.push("Show details");
  if (/report|analy|comp/i.test(text)) actions.push("Generate report");
  if (/call|phone|contact/i.test(text)) actions.push("Log activity");
  if (actions.length === 0) actions.push("Show details");
  return actions.slice(0, 3);
}

function getDemoResponse(message: string): string {
  const msg = message.toLowerCase();

  if (msg.includes("focus") || msg.includes("today") || msg.includes("priority")) {
    return `Three priorities for today:\n\n1. **Mosley Motel** — at 75% probability, this is your most likely close. Push for final underwriting numbers and a buyer meeting this week.\n\n2. **Liberty Square** — largest weighted deal at $137.5K. Two pending leases (Party Chasers, Pyro Payaso) still show no commission recorded. Chase those down.\n\n3. **Portage deals** — both Portage Land and Portage Retail are stuck in Lead stage. They need momentum. Want me to draft outreach to Shalin and Kelpesh?`;
  }

  if (msg.includes("kelpesh") || msg.includes("patel")) {
    return `Kelpesh Patel is involved in 3 active deals:\n\n• **Super 8 Hotel** — $3.8M, 65% probability, $74.1K weighted. Currently in Touring stage.\n• **Portage Retail** — $925K, 25% probability, $6.9K weighted. Still in Lead stage — needs attention.\n• **Shopping Center** — $699K, 40% probability, $19.6K weighted. Touring stage.\n\nTotal weighted exposure with Kelpesh: **$100,572**. He's your most active client. Want me to draft a status update email to him covering all three properties?`;
  }

  if (msg.includes("liberty") || msg.includes("square")) {
    return `Liberty Square is your highest-value deal:\n\n• **Sale**: $5.5M asking, 5% commission = $275K potential, 50% probability ($137.5K weighted)\n• **Owner**: LSH (Liberty Square Holdings)\n• **Stage**: Touring/Underwriting\n• **Closed leases on-site**: 7 total — Bashes Events, Next Level Performance, Rage Room, ATC Supply (x2), Party Chasers, Pyro Payaso\n• **Earned commission from leases**: $14,594\n\nThis is your flagship listing. The 48,327 SF retail center at 9.28% cap rate is compelling for investors. Want me to pull comps or draft an LOI template?`;
  }

  return `Based on your pipeline, your hottest deal is Mosley Motel at 75% probability ($49,500 weighted). Liberty Square has the highest upside at $137,500 weighted but sits at 50%. I'd recommend scheduling tours for both Portage deals — they're still in Lead stage and need momentum. Want me to draft outreach for those?`;
}
